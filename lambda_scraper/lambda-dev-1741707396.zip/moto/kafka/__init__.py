from .models import kafka_backends  # noqa: F401

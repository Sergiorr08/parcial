"""Exceptions raised by the kafka service."""
